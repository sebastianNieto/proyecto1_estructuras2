struct Cliente
{
	int id;
	char cedula[10];
	char nombre[30];
	char direccion[30];
	char telefono[10];
} usuario, copiaUsuario, *pUsuario = &usuario, *pCopiaUsuario = &copiaUsuario;

bool crear_cliente()
{
	FILE *archivo;
	
	archivo = fopen("datos/clientes.txt", "rb");
	
	if(archivo == NULL)
	{
		return false;
	}
	rewind(archivo);
	fseek(archivo,ftell(archivo)-sizeof(*pUsuario),SEEK_END);
	fread(pUsuario, sizeof(*pUsuario), 1, archivo);
	pUsuario->id = pUsuario->id+1;
	fclose(archivo);
	color(amarillo);
	fflush(stdin);
	gotoxy(24,4);printf("Numero de cedula del cliente");
	color(grisclaro);
	gotoxy(24,5);fgets(pUsuario->cedula, 10, stdin);
	color(amarillo);
	fflush(stdin);
	gotoxy(24,7);printf("Nombre del cliente");
	color(grisclaro);
	gotoxy(24,8);fgets(pUsuario->nombre, 30, stdin);
	fflush(stdin);
	color(amarillo);
	fflush(stdin);
	gotoxy(24,10);printf("Direccion de cliente");
	color(grisclaro);
	gotoxy(24,11);fgets(pUsuario->direccion, 10, stdin);
	fflush(stdin);
	color(amarillo);
	fflush(stdin);
	gotoxy(24,13);printf("Telefono del cliente");
	color(grisclaro);
	gotoxy(24,14);fgets(pUsuario->telefono, 10, stdin);
	fflush(stdin);
	
	archivo = fopen("datos/clientes.txt", "ab");
	
	if(archivo == NULL)
	{
		color(rojoclaro);
		gotoxy(24, 16);printf("No se pudo guardar el registro");
	}
	else
	{
		fwrite(pUsuario,sizeof(*pUsuario),1,archivo);
		rewind(archivo);
		fclose(archivo);
		color(verdeclaro);
		gotoxy(32, 16);printf("Registro Exitos");
	}
}

void encabezado_tabla(int y)
{
	color(amarillo);
	dibujaRectangulo(2,y-1,90,y+1,'\372');
	color(azulclaro);
	gotoxy(3, y);printf("Id");
	color(amarillo);
	gotoxy(6, y);printf("\263");
	color(azulclaro);
	gotoxy(7, y);printf("Cedula");
	color(amarillo);
	gotoxy(17, y);printf("\263");
	color(azulclaro);
	gotoxy(18, y);printf("Nombre");
	color(amarillo);
	gotoxy(48, y);printf("\263");
	color(azulclaro);
	gotoxy(49, y);printf("Direccion");
	color(amarillo);
	gotoxy(79, y);printf("\263");
	color(azulclaro);
	gotoxy(80, y);printf("Telefono");
}

void cuerpo_tabla(Cliente *pUsuario, int y)
{
	
	color(amarillo);
	dibujaRectangulo(2,y-1,90,y+1,'\372');
	color(grisclaro);
	gotoxy(3, y);printf("%d", pUsuario->id);
	color(amarillo);
	gotoxy(6, y);printf("\263");
	color(grisclaro);
	gotoxy(7, y);printf("%s", pUsuario->cedula);
	color(amarillo);
	gotoxy(17, y);printf("\263");
	color(grisclaro);
	gotoxy(18, y);printf("%s", pUsuario->nombre);
	color(amarillo);
	gotoxy(48, y);printf("\263");
	color(grisclaro);
	gotoxy(49, y);printf("%s", pUsuario->direccion);
	color(amarillo);
	gotoxy(79, y);printf("\263");
	color(grisclaro);
	gotoxy(80, y);printf("%s", pUsuario->telefono);
}

bool mostrar_clientes()
{
	FILE *archivo;
	int y = 4;
	
	archivo = fopen("datos/clientes.txt", "rb");
	
	if(archivo == NULL)
	{
		return false;
	}
	else
	{
		encabezado_tabla(2);
		while(fread(pUsuario, sizeof(*pUsuario), 1, archivo))
		{
			cuerpo_tabla(pUsuario, y);
			y+=2;
		}
	}
	fclose(archivo);
}

int buscar_cliente(int *pBuscar)
{
	FILE *archivo;
	int indice = 0, *pIndice = &indice;
	bool bandera = false, *pBandera = &bandera;
	archivo = fopen("datos/clientes.txt", "rb");
	
	if(archivo == NULL)
	{
		return false;
	}
	else
	{
		while(fread(pUsuario, sizeof(*pUsuario), 1, archivo))
		{
			if(*pBuscar == pUsuario->id)
			{
				encabezado_tabla(2);
				cuerpo_tabla(pUsuario, 4);
				*pBandera = true;
				break;
			}
			
			(*pIndice)++;
		}
		fclose(archivo);
		if(!*pBandera)
		{
			color(rojo);
			gotoxy(24,12);printf("No se encontro ningun registro");
			getch();
			return 0;
		}
		else
		{
			return *pIndice;
		}
	}
}

void editar_cliente(int *pUbicacion)
{
	int opcion = 0, *pOpcion = &opcion;
	
	FILE *archivo;
	archivo = fopen("datos/clientes.txt", "rb+");
	fseek(archivo,sizeof(*pUsuario)* *pUbicacion,SEEK_SET);
	
	do{
		color(amarillo);
		gotoxy(33,10);printf("Escoge el campo a editar");
		color(grisclaro);
		gotoxy(33,12);printf("1: Cedula");
		gotoxy(33,13);printf("2: Nombre");
		gotoxy(33,14);printf("3: Direccion");
		gotoxy(33,15);printf("4: Telefono");
		gotoxy(33,18);printf("0: Cancelar \n");
		color(verde);
		gotoxy(33,20);printf("Ingresa la opcion: ");
		scanf("%d", &opcion);
		gotoxy(33,22);printf("Ingrese el nuevo valor: ");
		fflush(stdin);
		switch(opcion)
		{
			case 0:
			{
				break;
			}
			case 1:
			{
				gotoxy(33,23);fgets(pUsuario->cedula, 10, stdin);
				fwrite(pUsuario,sizeof(*pUsuario),1,archivo);
				break;
			}
			case 2:
			{
				gotoxy(33,23);fgets(pUsuario->nombre, 30, stdin);
				fwrite(pUsuario,sizeof(*pUsuario),1,archivo);
				break;
			}
			case 3:
			{
				gotoxy(33,23);fgets(pUsuario->direccion, 30, stdin);
				fwrite(pUsuario,sizeof(*pUsuario),1,archivo);
				break;
			}
			case 4:
			{
				gotoxy(33,23);fgets(pUsuario->telefono, 10, stdin);
				fwrite(pUsuario,sizeof(*pUsuario),1,archivo);
				break;
			}
		}
		fflush(stdin);
	} while(*pOpcion != 0);
	
	fclose(archivo);
}

