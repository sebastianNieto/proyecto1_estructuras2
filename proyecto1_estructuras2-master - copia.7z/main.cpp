#include<iostream>
#include<stdio.h>
#include<windows.h>
#include<conio.h>
#include"estilo.h"
#include"cliente.h"
#include"menu.h"


int main (int argc, char *argv[]) {
	
	menu();
	return 0;
}

